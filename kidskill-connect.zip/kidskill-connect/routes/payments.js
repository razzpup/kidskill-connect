const express = require("express");
const db = require("../db");
const { requireRole } = require("./helpers");

const router = express.Router();

router.get("/bookings/:id/pay", requireRole("parent"), (req, res) => {
  const booking = db.prepare(`
    SELECT b.*, u.name AS provider_name FROM bookings b
    JOIN users u ON u.id = b.provider_id
    WHERE b.id = ?
  `).get(req.params.id);

  if (!booking || booking.parent_id !== req.session.user.id) {
    req.flash("error", "Booking not found.");
    return res.redirect("/dashboard/parent");
  }
  if (booking.status !== "accepted") {
    req.flash("error", "This booking isn't ready for payment yet.");
    return res.redirect(`/bookings/${booking.id}`);
  }

  res.render("payment", { booking });
});

// Sandbox/test-mode payment gateway — no real money moves.
// Mimics how Razorpay/Stripe test mode works: specific test card numbers
// trigger success or decline, so the full flow is exercised end-to-end.
router.post("/bookings/:id/pay", requireRole("parent"), (req, res) => {
  const booking = db.prepare("SELECT * FROM bookings WHERE id = ?").get(req.params.id);
  if (!booking || booking.parent_id !== req.session.user.id) {
    req.flash("error", "Booking not found.");
    return res.redirect("/dashboard/parent");
  }
  if (booking.status !== "accepted") {
    req.flash("error", "This booking isn't ready for payment yet.");
    return res.redirect(`/bookings/${booking.id}`);
  }

  const cardNumber = (req.body.card_number || "").replace(/\s/g, "");
  const DECLINE_TEST_CARD = "4000000000000002";
  const isDeclineCard = cardNumber === DECLINE_TEST_CARD;

  if (isDeclineCard) {
    db.prepare(
      "INSERT INTO payments (booking_id, amount, commission_amount, provider_payout, status, test_card_used) VALUES (?,?,?,?,?,?)"
    ).run(booking.id, booking.amount, booking.commission_amount, booking.provider_payout, "failed", cardNumber);
    req.flash("error", "Payment declined by the test card. Try the success test card instead.");
    return res.redirect(`/bookings/${booking.id}/pay`);
  }

  db.prepare(
    "INSERT INTO payments (booking_id, amount, commission_amount, provider_payout, status, test_card_used) VALUES (?,?,?,?,?,?)"
  ).run(booking.id, booking.amount, booking.commission_amount, booking.provider_payout, "success", cardNumber);

  db.prepare("UPDATE bookings SET status = 'paid', updated_at = datetime('now') WHERE id = ?").run(booking.id);

  req.flash("success", "Payment successful! Your booking is confirmed.");
  res.redirect(`/bookings/${booking.id}`);
});

module.exports = router;
