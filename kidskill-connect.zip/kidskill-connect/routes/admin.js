const express = require("express");
const db = require("../db");
const { requireRole } = require("./helpers");

const router = express.Router();

router.get("/admin", requireRole("admin"), (req, res) => {
  const pending = db.prepare(`
    SELECT u.id, u.name, u.email, u.phone, p.* FROM provider_profiles p
    JOIN users u ON u.id = p.user_id
    WHERE p.status = 'pending' ORDER BY p.created_at DESC
  `).all();

  const allProviders = db.prepare(`
    SELECT u.id, u.name, u.email, p.skill_category, p.locality, p.status FROM provider_profiles p
    JOIN users u ON u.id = p.user_id
    ORDER BY p.created_at DESC
  `).all();

  const transactions = db.prepare(`
    SELECT pay.*, b.id AS booking_id, up.name AS parent_name, uv.name AS provider_name
    FROM payments pay
    JOIN bookings b ON b.id = pay.booking_id
    JOIN users up ON up.id = b.parent_id
    JOIN users uv ON uv.id = b.provider_id
    ORDER BY pay.created_at DESC
  `).all();

  const totals = db.prepare(`
    SELECT
      COALESCE(SUM(CASE WHEN status='success' THEN amount ELSE 0 END),0) AS gross,
      COALESCE(SUM(CASE WHEN status='success' THEN commission_amount ELSE 0 END),0) AS commission,
      COALESCE(SUM(CASE WHEN status='success' THEN provider_payout ELSE 0 END),0) AS payouts,
      COALESCE(SUM(CASE WHEN status='success' THEN 1 ELSE 0 END),0) AS successful_count,
      COALESCE(SUM(CASE WHEN status='failed' THEN 1 ELSE 0 END),0) AS failed_count
    FROM payments
  `).get();

  const stats = {
    totalParents: db.prepare("SELECT COUNT(*) c FROM users WHERE role='parent'").get().c,
    totalProviders: db.prepare("SELECT COUNT(*) c FROM users WHERE role='provider'").get().c,
    totalBookings: db.prepare("SELECT COUNT(*) c FROM bookings").get().c,
  };

  res.render("admin_dashboard", { pending, allProviders, transactions, totals, stats });
});

router.post("/admin/providers/:id/approve", requireRole("admin"), (req, res) => {
  db.prepare("UPDATE provider_profiles SET status = 'approved' WHERE user_id = ?").run(req.params.id);
  req.flash("success", "Provider approved and now live on the platform.");
  res.redirect("/admin");
});

router.post("/admin/providers/:id/reject", requireRole("admin"), (req, res) => {
  db.prepare("UPDATE provider_profiles SET status = 'rejected' WHERE user_id = ?").run(req.params.id);
  req.flash("success", "Provider rejected.");
  res.redirect("/admin");
});

module.exports = router;
