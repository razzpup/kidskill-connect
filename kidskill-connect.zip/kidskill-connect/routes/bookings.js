const express = require("express");
const db = require("../db");
const { requireRole } = require("./helpers");

const router = express.Router();

// Parent requests a booking with a provider
router.post("/providers/:id/request", requireRole("parent"), (req, res) => {
  const providerId = req.params.id;
  const { kid_name, kid_age, preferred_date, message, amount } = req.body;

  const profile = db.prepare("SELECT * FROM provider_profiles WHERE user_id = ? AND status='approved'").get(providerId);
  if (!profile) {
    req.flash("error", "That provider isn't available right now.");
    return res.redirect("/providers");
  }

  const amt = Number(amount) || profile.price_min || 0;
  const rate = 0.15;
  const commission = Math.round(amt * rate);
  const payout = amt - commission;

  const info = db.prepare(`
    INSERT INTO bookings (parent_id, provider_id, kid_name, kid_age, preferred_date, message, amount, commission_rate, commission_amount, provider_payout, status)
    VALUES (?,?,?,?,?,?,?,?,?,?, 'requested')
  `).run(req.session.user.id, providerId, kid_name || null, Number(kid_age) || null, preferred_date || null, message || null, amt, rate, commission, payout);

  req.flash("success", "Request sent! You'll be notified once the provider responds.");
  res.redirect(`/bookings/${info.lastInsertRowid}`);
});

router.get("/bookings/:id", (req, res) => {
  const booking = db.prepare(`
    SELECT b.*, up.name AS parent_name, uv.name AS provider_name, uv.id AS provider_user_id
    FROM bookings b
    JOIN users up ON up.id = b.parent_id
    JOIN users uv ON uv.id = b.provider_id
    WHERE b.id = ?
  `).get(req.params.id);

  if (!booking) return res.status(404).render("404");

  const user = req.session.user;
  const isParty = user && (user.id === booking.parent_id || user.id === booking.provider_id);
  if (!isParty) {
    req.flash("error", "You don't have access to that booking.");
    return res.redirect("/");
  }

  const review = db.prepare("SELECT * FROM reviews WHERE booking_id = ?").get(req.params.id);

  res.render("booking_detail", { booking, review, isParent: user.id === booking.parent_id, isProvider: user.id === booking.provider_id });
});

// Provider accepts / declines
router.post("/bookings/:id/respond", requireRole("provider"), (req, res) => {
  const { decision } = req.body; // 'accepted' | 'declined'
  const booking = db.prepare("SELECT * FROM bookings WHERE id = ?").get(req.params.id);
  if (!booking || booking.provider_id !== req.session.user.id) {
    req.flash("error", "Booking not found.");
    return res.redirect("/dashboard/provider");
  }
  if (booking.status !== "requested") {
    req.flash("error", "This request has already been responded to.");
    return res.redirect(`/bookings/${booking.id}`);
  }
  const status = decision === "accepted" ? "accepted" : "declined";
  db.prepare("UPDATE bookings SET status = ?, updated_at = datetime('now') WHERE id = ?").run(status, booking.id);
  req.flash("success", status === "accepted" ? "Booking accepted — the parent can now pay to confirm." : "Booking declined.");
  res.redirect(`/bookings/${booking.id}`);
});

// Parent marks a paid booking as completed (after the session happened), enabling a review
router.post("/bookings/:id/complete", requireRole("parent"), (req, res) => {
  const booking = db.prepare("SELECT * FROM bookings WHERE id = ?").get(req.params.id);
  if (!booking || booking.parent_id !== req.session.user.id) {
    req.flash("error", "Booking not found.");
    return res.redirect("/dashboard/parent");
  }
  if (booking.status !== "paid") {
    req.flash("error", "Only paid bookings can be marked complete.");
    return res.redirect(`/bookings/${booking.id}`);
  }
  db.prepare("UPDATE bookings SET status = 'completed', updated_at = datetime('now') WHERE id = ?").run(booking.id);
  req.flash("success", "Marked as completed. You can now leave a review!");
  res.redirect(`/bookings/${booking.id}`);
});

router.post("/bookings/:id/review", requireRole("parent"), (req, res) => {
  const { rating, comment } = req.body;
  const booking = db.prepare("SELECT * FROM bookings WHERE id = ?").get(req.params.id);
  if (!booking || booking.parent_id !== req.session.user.id) {
    req.flash("error", "Booking not found.");
    return res.redirect("/dashboard/parent");
  }
  if (booking.status !== "completed") {
    req.flash("error", "You can only review a completed session.");
    return res.redirect(`/bookings/${booking.id}`);
  }
  const existing = db.prepare("SELECT id FROM reviews WHERE booking_id = ?").get(booking.id);
  if (existing) {
    req.flash("error", "You've already reviewed this session.");
    return res.redirect(`/bookings/${booking.id}`);
  }
  db.prepare("INSERT INTO reviews (booking_id, parent_id, provider_id, rating, comment) VALUES (?,?,?,?,?)")
    .run(booking.id, booking.parent_id, booking.provider_id, Number(rating), comment || null);

  req.flash("success", "Thanks for your review!");
  res.redirect(`/bookings/${booking.id}`);
});

// ---- Parent dashboard ----
router.get("/dashboard/parent", requireRole("parent"), (req, res) => {
  const bookings = db.prepare(`
    SELECT b.*, u.name AS provider_name, pp.skill_category FROM bookings b
    JOIN users u ON u.id = b.provider_id
    JOIN provider_profiles pp ON pp.user_id = b.provider_id
    WHERE b.parent_id = ? ORDER BY b.created_at DESC
  `).all(req.session.user.id);

  res.render("parent_dashboard", { bookings });
});

module.exports = router;
