function requireLogin(req, res, next) {
  if (!req.session.user) {
    req.flash("error", "Please log in to continue.");
    return res.redirect("/login");
  }
  next();
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.session.user) {
      req.flash("error", "Please log in to continue.");
      return res.redirect("/login");
    }
    if (req.session.user.role !== role) {
      req.flash("error", "You don't have access to that page.");
      return res.redirect("/");
    }
    next();
  };
}

module.exports = { requireLogin, requireRole };
