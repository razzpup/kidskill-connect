const express = require("express");
const db = require("../db");
const { requireRole } = require("./helpers");

const router = express.Router();

router.get("/providers", (req, res) => {
  const { category, locality, age, mode, sort } = req.query;

  let sql = `
    SELECT u.id, u.name, p.*,
      (SELECT ROUND(AVG(r.rating),1) FROM reviews r WHERE r.provider_id = u.id) AS avg_rating,
      (SELECT COUNT(*) FROM reviews r WHERE r.provider_id = u.id) AS review_count
    FROM provider_profiles p
    JOIN users u ON u.id = p.user_id
    WHERE p.status = 'approved'
  `;
  const params = [];

  if (category) {
    sql += " AND p.skill_category = ?";
    params.push(category);
  }
  if (locality) {
    sql += " AND p.locality LIKE ?";
    params.push(`%${locality}%`);
  }
  if (mode) {
    sql += mode === "both" ? " AND p.mode = 'both'" : " AND (p.mode = ? OR p.mode = 'both')";
    if (mode !== "both") params.push(mode);
  }
  if (age) {
    // simple containment check against "min-max" stored as text like "6-16"
    sql += ` AND (
      CAST(substr(p.age_group,1,instr(p.age_group,'-')-1) AS INTEGER) <= ?
      AND CAST(substr(p.age_group,instr(p.age_group,'-')+1) AS INTEGER) >= ?
    )`;
    params.push(Number(age), Number(age));
  }

  sql += sort === "price_low" ? " ORDER BY p.price_min ASC"
    : sort === "price_high" ? " ORDER BY p.price_max DESC"
    : sort === "rating" ? " ORDER BY avg_rating DESC"
    : " ORDER BY p.created_at DESC";

  const providers = db.prepare(sql).all(...params);
  const localities = db.prepare("SELECT DISTINCT locality FROM provider_profiles WHERE status='approved' AND locality IS NOT NULL").all().map(r => r.locality);

  res.render("providers", {
    providers, localities,
    filters: { category: category || "", locality: locality || "", age: age || "", mode: mode || "", sort: sort || "" },
  });
});

router.get("/providers/:id", (req, res) => {
  const provider = db.prepare(`
    SELECT u.id, u.name, u.email, u.phone, p.* FROM provider_profiles p
    JOIN users u ON u.id = p.user_id
    WHERE u.id = ? AND p.status = 'approved'
  `).get(req.params.id);

  if (!provider) return res.status(404).render("404");

  const reviews = db.prepare(`
    SELECT r.*, u.name AS parent_name FROM reviews r
    JOIN users u ON u.id = r.parent_id
    WHERE r.provider_id = ? ORDER BY r.created_at DESC
  `).all(req.params.id);

  const avgRating = reviews.length ? (reviews.reduce((a, r) => a + r.rating, 0) / reviews.length).toFixed(1) : null;

  res.render("provider_detail", { provider, reviews, avgRating });
});

// ---- Provider dashboard ----
router.get("/dashboard/provider", requireRole("provider"), (req, res) => {
  const profile = db.prepare("SELECT * FROM provider_profiles WHERE user_id = ?").get(req.session.user.id);
  const bookings = db.prepare(`
    SELECT b.*, u.name AS parent_name, u.phone AS parent_phone FROM bookings b
    JOIN users u ON u.id = b.parent_id
    WHERE b.provider_id = ? ORDER BY b.created_at DESC
  `).all(req.session.user.id);

  const earnings = db.prepare(`
    SELECT COALESCE(SUM(provider_payout),0) AS total FROM bookings
    WHERE provider_id = ? AND status IN ('paid','completed')
  `).get(req.session.user.id).total;

  res.render("provider_dashboard", { profile, bookings, earnings, CATEGORIES: res.locals.CATEGORIES });
});

router.post("/dashboard/provider/update", requireRole("provider"), (req, res) => {
  const { skill_category, headline, bio, locality, mode, age_group, price_min, price_max, availability_note } = req.body;
  db.prepare(`
    UPDATE provider_profiles SET
      skill_category = ?, headline = ?, bio = ?, locality = ?, mode = ?, age_group = ?,
      price_min = ?, price_max = ?, availability_note = ?
    WHERE user_id = ?
  `).run(skill_category, headline, bio, locality, mode, age_group, Number(price_min) || 0, Number(price_max) || 0, availability_note, req.session.user.id);

  req.flash("success", "Profile updated.");
  res.redirect("/dashboard/provider");
});

module.exports = router;
