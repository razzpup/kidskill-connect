const express = require("express");
const bcrypt = require("bcryptjs");
const multer = require("multer");
const path = require("path");
const db = require("../db");

const router = express.Router();

const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, "..", "uploads"),
    filename: (req, file, cb) => {
      cb(null, Date.now() + "-" + file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, "_"));
    },
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
});

router.get("/register", (req, res) => {
  res.render("register_choose");
});

router.get("/register/parent", (req, res) => {
  res.render("register_parent", { form: {} });
});

router.post("/register/parent", (req, res) => {
  const { name, email, password, phone, locality } = req.body;
  if (!name || !email || !password) {
    req.flash("error", "Name, email and password are required.");
    return res.redirect("/register/parent");
  }
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) {
    req.flash("error", "An account with that email already exists.");
    return res.redirect("/register/parent");
  }
  const hash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare("INSERT INTO users (role, name, email, password_hash, phone, locality) VALUES (?,?,?,?,?,?)")
    .run("parent", name, email, hash, phone || null, locality || null);

  req.session.user = { id: info.lastInsertRowid, role: "parent", name };
  req.flash("success", `Welcome, ${name}! Your parent account is ready.`);
  res.redirect("/providers");
});

router.get("/register/provider", (req, res) => {
  res.render("register_provider", { form: {}, CATEGORIES: res.locals.CATEGORIES });
});

router.post("/register/provider", upload.single("credential_file"), (req, res) => {
  const {
    name, email, password, phone, locality,
    skill_category, headline, bio, mode, age_group, price_min, price_max, availability_note,
  } = req.body;

  if (!name || !email || !password || !skill_category) {
    req.flash("error", "Name, email, password and a skill category are required.");
    return res.redirect("/register/provider");
  }
  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email);
  if (existing) {
    req.flash("error", "An account with that email already exists.");
    return res.redirect("/register/provider");
  }
  const hash = bcrypt.hashSync(password, 10);
  const userInfo = db
    .prepare("INSERT INTO users (role, name, email, password_hash, phone, locality) VALUES (?,?,?,?,?,?)")
    .run("provider", name, email, hash, phone || null, locality || null);

  const credentialFile = req.file ? "/uploads/" + req.file.filename : null;

  db.prepare(
    `INSERT INTO provider_profiles
      (user_id, skill_category, headline, bio, locality, mode, age_group, price_min, price_max, availability_note, credential_file, status)
     VALUES (?,?,?,?,?,?,?,?,?,?,?, 'pending')`
  ).run(
    userInfo.lastInsertRowid, skill_category, headline || null, bio || null, locality || null,
    mode || "in-person", age_group || null, Number(price_min) || 0, Number(price_max) || 0,
    availability_note || null, credentialFile
  );

  req.session.user = { id: userInfo.lastInsertRowid, role: "provider", name };
  req.flash("success", "Profile submitted! It's now pending admin review — you'll be listed once approved.");
  res.redirect("/dashboard/provider");
});

router.get("/login", (req, res) => {
  res.render("login");
});

router.post("/login", (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  if (!user || !bcrypt.compareSync(password || "", user.password_hash)) {
    req.flash("error", "Invalid email or password.");
    return res.redirect("/login");
  }
  req.session.user = { id: user.id, role: user.role, name: user.name };
  req.flash("success", `Welcome back, ${user.name}!`);
  if (user.role === "admin") return res.redirect("/admin");
  if (user.role === "provider") return res.redirect("/dashboard/provider");
  res.redirect("/dashboard/parent");
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/"));
});

module.exports = router;
