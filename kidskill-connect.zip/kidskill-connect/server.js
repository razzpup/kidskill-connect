const express = require("express");
const session = require("express-session");
const path = require("path");
const flash = require("connect-flash");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use("/public", express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

app.use(
  session({
    secret: "kidskill-connect-hackathon-secret-change-in-prod",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 8 },
  })
);
app.use(flash());

// make current user + flash messages available in all views
app.use((req, res, next) => {
  res.locals.currentUser = req.session.user || null;
  res.locals.success = req.flash("success");
  res.locals.error = req.flash("error");
  next();
});

const CATEGORIES = ["Singing", "Dancing", "Sports", "Arts", "Computers"];
app.use((req, res, next) => {
  res.locals.CATEGORIES = CATEGORIES;
  next();
});

app.use("/", require("./routes/auth"));
app.use("/", require("./routes/providers"));
app.use("/", require("./routes/bookings"));
app.use("/", require("./routes/payments"));
app.use("/", require("./routes/admin"));

app.get("/", (req, res) => {
  const featured = db
    .prepare(
      `SELECT u.id, u.name, p.* FROM provider_profiles p
       JOIN users u ON u.id = p.user_id
       WHERE p.status = 'approved'
       ORDER BY RANDOM() LIMIT 4`
    )
    .all();
  res.render("home", { featured });
});

app.use((req, res) => {
  res.status(404).render("404");
});

app.listen(PORT, () => {
  console.log(`KidSkill Connect running at http://localhost:${PORT}`);
});
