const { DatabaseSync } = require("node:sqlite");
const bcrypt = require("bcryptjs");
const path = require("path");

const db = new DatabaseSync(path.join(__dirname, "data", "kidskill.db"));
db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL CHECK(role IN ('parent','provider','admin')),
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  phone TEXT,
  locality TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS provider_profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  skill_category TEXT NOT NULL,
  headline TEXT,
  bio TEXT,
  locality TEXT,
  mode TEXT NOT NULL DEFAULT 'in-person' CHECK(mode IN ('in-person','online','both')),
  age_group TEXT,
  price_min INTEGER DEFAULT 0,
  price_max INTEGER DEFAULT 0,
  availability_note TEXT,
  credential_file TEXT,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_id INTEGER NOT NULL REFERENCES users(id),
  provider_id INTEGER NOT NULL REFERENCES users(id),
  kid_name TEXT,
  kid_age INTEGER,
  preferred_date TEXT,
  message TEXT,
  status TEXT NOT NULL DEFAULT 'requested' CHECK(status IN ('requested','accepted','declined','paid','completed','cancelled')),
  amount INTEGER DEFAULT 0,
  commission_rate REAL DEFAULT 0.15,
  commission_amount INTEGER DEFAULT 0,
  provider_payout INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL REFERENCES bookings(id),
  amount INTEGER NOT NULL,
  commission_amount INTEGER NOT NULL,
  provider_payout INTEGER NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('success','failed')),
  test_card_used TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS reviews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER NOT NULL REFERENCES bookings(id),
  parent_id INTEGER NOT NULL REFERENCES users(id),
  provider_id INTEGER NOT NULL REFERENCES users(id),
  rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
`);

// ---- seed data (idempotent) ----
const userCount = db.prepare("SELECT COUNT(*) AS c FROM users").get().c;
if (userCount === 0) {
  const insertUser = db.prepare(
    `INSERT INTO users (role, name, email, password_hash, phone, locality) VALUES (?,?,?,?,?,?)`
  );
  const insertProfile = db.prepare(`
    INSERT INTO provider_profiles
      (user_id, skill_category, headline, bio, locality, mode, age_group, price_min, price_max, availability_note, status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?)
  `);

  const hash = (pw) => bcrypt.hashSync(pw, 10);

  // Admin
  db.prepare(`INSERT INTO users (role,name,email,password_hash,phone,locality) VALUES (?,?,?,?,?,?)`)
    .run("admin", "Platform Admin", "admin@kidskillconnect.in", hash("admin123"), "9999999999", "Bangalore");

  // Demo parent
  const parentId = insertUser.run("parent", "Anjali Rao", "parent@example.com", hash("parent123"), "9876500001", "Indiranagar").lastInsertRowid;

  // Demo providers (approved, so they show up immediately)
  const providers = [
    { name: "Sneha Kulkarni", email: "sneha@example.com", skill: "Singing", headline: "Hindustani & Western Vocals for Kids", bio: "Trained vocalist with 8 years teaching children aged 6-16. Focus on breathing, pitch, and stage confidence.", locality: "Indiranagar", mode: "both", age: "6-16", pmin: 800, pmax: 1500 },
    { name: "Rahul Mehta", email: "rahul@example.com", skill: "Dancing", headline: "Hip-Hop & Contemporary for Kids", bio: "Ex-competitive dancer, now teaching high-energy hip-hop and contemporary to kids aged 5-14.", locality: "Koramangala", mode: "in-person", age: "5-14", pmin: 600, pmax: 1200 },
    { name: "Arjun Nair", email: "arjun@example.com", skill: "Sports", headline: "Football & Badminton Coaching", bio: "State-level football coach running weekend batches for kids 7-15. Focus on fundamentals and fitness.", locality: "HSR Layout", mode: "in-person", age: "7-15", pmin: 700, pmax: 1400 },
    { name: "Meera Iyer", email: "meera@example.com", skill: "Arts", headline: "Sketching, Watercolor & Craft", bio: "Fine arts graduate teaching sketching and watercolor to young kids in a fun, pressure-free style.", locality: "Jayanagar", mode: "both", age: "4-12", pmin: 500, pmax: 1000 },
    { name: "Karthik Subramaniam", email: "karthik@example.com", skill: "Computers", headline: "Scratch Coding & Robotics Basics", bio: "Software engineer teaching Scratch programming and basic robotics kits to kids 8-15.", locality: "Whitefield", mode: "online", age: "8-15", pmin: 900, pmax: 1800 },
    { name: "Divya Prakash", email: "divya@example.com", skill: "Singing", headline: "Carnatic Vocals — Beginner Friendly", bio: "Carnatic-trained vocalist, patient with true beginners aged 5 and up.", locality: "Jayanagar", mode: "in-person", age: "5-13", pmin: 600, pmax: 1100 },
    { name: "Farhan Sheikh", email: "farhan@example.com", skill: "Dancing", headline: "Bollywood & Freestyle", bio: "Choreographer for school events, now teaching Bollywood-style dance to kids 6-15.", locality: "Indiranagar", mode: "both", age: "6-15", pmin: 550, pmax: 1050 },
    { name: "Priya Das", email: "priya@example.com", skill: "Arts", headline: "Clay Modelling & Craft for Little Ones", bio: "Specializes in tactile art for younger kids aged 4-9 — clay, collage, and simple painting.", locality: "Koramangala", mode: "in-person", age: "4-9", pmin: 450, pmax: 900 },
  ];

  for (const p of providers) {
    const uid = insertUser.run("provider", p.name, p.email, hash("provider123"), "98765" + Math.floor(10000 + Math.random() * 89999), p.locality).lastInsertRowid;
    insertProfile.run(uid, p.skill, p.headline, p.bio, p.locality, p.mode, p.age, p.pmin, p.pmax, "Weekday evenings & weekend mornings", "approved");
  }

  // One pending provider, for the admin-vetting demo
  const pendingId = insertUser.run("provider", "Vikram Singh", "vikram@example.com", hash("provider123"), "9876554321", "Whitefield").lastInsertRowid;
  insertProfile.run(pendingId, "Sports", "Cricket Coaching — Newly Joined", "Former club-level cricketer, new to the platform.", "Whitefield", "in-person", "8-16", 700, 1300, "Weekend mornings", "pending");

  console.log("Seed data inserted.");
}

module.exports = db;
