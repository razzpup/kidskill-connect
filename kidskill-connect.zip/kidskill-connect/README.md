# KidSkill Connect

A working full-stack marketplace connecting parents with vetted freelance skill-training
providers for kids (singing, dancing, sports, arts, computers) in Bangalore.

Built for a hackathon — this is a **real, working application**: real backend, real
database, real authentication, a full booking lifecycle, and a payment gateway running
in **sandbox/test mode** (no real money moves, but the flow is fully functional end to end).

---

## What's actually working

- **Real backend & database** — Node.js/Express + SQLite (via `better-sqlite3`). Data
  persists across restarts in `data/kidskill.db`.
- **Real authentication** — bcrypt-hashed passwords, server-side sessions. Separate
  registration/login flows for Parents and Providers.
- **Search & filters** — browse providers by category, locality, kid's age, mode
  (in-person/online), sorted by price or rating.
- **Full booking lifecycle** — Parent requests → Provider accepts/declines → Parent pays
  → session happens → Parent marks complete → Parent leaves a rating & review.
- **Payments (sandbox/test mode)** — mimics how Razorpay/Stripe test mode works: a
  specific test card number succeeds, another declines, so the whole payment flow is
  exercised without moving real money. See [Payments](#payments--test-mode) below for
  how to swap in a real gateway.
- **Admin dashboard** — approve/reject provider applications (with uploaded credential
  file review), see all listings, and view every transaction with commission breakdown.
- **Mobile-responsive** design.

## Quick start

Requires [Node.js](https://nodejs.org) 18+.

```bash
npm install
npm start
```

Then open **http://localhost:3000**.

The database is created and seeded automatically on first run (`data/kidskill.db`) —
no separate setup step needed. To reset to a clean seeded state at any point, just
delete the `data/` folder's `.db*` files and restart the server.

## Demo logins

The seed data includes ready-to-use accounts:

| Role | Email | Password |
|---|---|---|
| Parent | `parent@example.com` | `parent123` |
| Provider (approved) | `sneha@example.com` | `provider123` |
| Provider (pending — try approving them as admin) | `vikram@example.com` | `provider123` |
| Admin | `admin@kidskillconnect.in` | `admin123` |

There are 7 pre-approved providers across all 5 categories (Singing, Dancing, Sports,
Arts, Computers) so `/providers` isn't empty on first load. Full list of provider demo
emails is in `db.js` (all use password `provider123`).

## Trying the full flow

1. Log in as the parent, browse `/providers`, and request a booking with a provider.
2. Log out, log in as that provider (`sneha@example.com`), and accept the request from
   their dashboard.
3. Log back in as the parent and pay using a **test card** (see below).
4. Mark the session complete, then leave a rating & review.
5. Log in as admin (`admin@kidskillconnect.in`) to see the transaction, commission
   breakdown, and approve the pending provider (Vikram) so he goes live.

## Payments — test mode

No real payment processor is connected. The checkout page mimics how Razorpay/Stripe
test mode behaves:

- Card `4111 1111 1111 1111` → payment **succeeds**
- Card `4000 0000 0000 0002` → payment **declines**
- Any expiry/CVV works

This is intentional for a hackathon demo — real gateway integration needs business KYC
that takes days to approve, which most hackathons don't expect you to have. To go live
with real payments, swap the logic in `routes/payments.js` for actual Razorpay/Stripe
server-side API calls (order creation + webhook verification) — the booking/commission
data model already supports it as-is.

## Project structure

```
server.js              — app entrypoint, middleware, session setup
db.js                   — SQLite schema + seed data (runs automatically)
routes/
  auth.js               — registration (parent/provider), login, logout
  providers.js           — browse/filter, provider profile, provider dashboard
  bookings.js             — request → accept/decline → complete → review
  payments.js              — sandbox payment gateway
  admin.js                  — provider vetting, transactions, commission totals
  helpers.js                 — auth guards
views/                        — EJS templates
public/css/style.css          — design system (bright, kid-friendly, mobile-responsive)
uploads/                      — provider-submitted credential files (gitignored)
data/                          — SQLite database file (created on first run)
```

## Deploying it live

This won't run inside the chat environment after the conversation ends — you'll need to
deploy it yourself. The fastest options for a hackathon:

**Render / Railway (recommended, ~10 minutes):**
1. Push this folder to a GitHub repo.
2. Create a new Web Service on [Render](https://render.com) or
   [Railway](https://railway.app), connect the repo.
3. Build command: `npm install` — Start command: `npm start`.
4. Note: SQLite writes to local disk, which most free hosting tiers **don't persist**
   across restarts/redeploys. Fine for a hackathon demo; for anything longer-lived,
   swap `better-sqlite3` for a hosted Postgres (e.g. via `pg`) — the query shapes are
   simple enough that this is a small change.

**Running locally for a live judged demo:**
```bash
npm install
npm start
```
Then use a tunnel like `ngrok http 3000` if judges need a public URL.

## Known limitations (be upfront about these if asked)

- Payments are sandboxed, not connected to a real processor (see above).
- SQLite is great for a demo but isn't built for concurrent production traffic — fine
  for a hackathon, worth swapping for Postgres/MySQL before any real launch.
- Session store is in-memory (default `express-session` store) — sessions reset if the
  server restarts. Fine for a demo; swap for `connect-sqlite3` or Redis for production.
- No email/SMS notifications on booking status changes — everything is check-the-page.
- Credential file upload has no virus scanning or format validation beyond file size.
